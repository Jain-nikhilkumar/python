We have created simple shop management system using python
first of all we need to run the home_page.py file to enter in our project
then you can experince our project
Thank You :)