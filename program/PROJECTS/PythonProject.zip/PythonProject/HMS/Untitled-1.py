Age = int(input())
if Age<18 :
    print("Minor")
elif Age=18:
    print("Is now 18")
else:
    print("Ok")