


def Zerodivi():
    nums=[1,2,0,3,8,4,6,2]
    try:
         for i in nums:
             ans=10/i
             print(ans)
    except ZeroDivisionError as err:
        print(err,"is not allowed !")

def IOErr():
    try:
        f=open("not_there.txt",'r')
    except IOError as er:
        print(er.filename,"->File is not present in Directory!")
def Syntax():
    try:
        x=10
        y=20
        eval('x===y')
    
    except SyntaxError:
        print("====","Operation Not Supported!")	
f=Zerodivi()
f=Syntax()
f=IOErr()


