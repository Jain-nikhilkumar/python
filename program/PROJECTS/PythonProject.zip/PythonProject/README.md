# PythonProject
industrial Training for Python 
