import tkinter as tk
from tkinter import messagebox
import sqlite3


# Function to create a new record
def create_record():
    name = entry_name.get()
    email = entry_email.get()

    if name and email:
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()
        cursor.execute("INSERT INTO contacts (name, email) VALUES (?, ?)", (name, email))
        conn.commit()
        conn.close()
        messagebox.showinfo("Success", "Record created successfully.")
        clear_entries()
        display_records()
    else:
        messagebox.showwarning("Warning", "Please enter both name and email.")

# Function to read records from the database
def display_records():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM contacts")
    rows = cursor.fetchall()
    conn.close()

    listbox_records.delete(0, tk.END)
    for row in rows:
        listbox_records.insert(tk.END, row)

# Function to update a record
def update_record():
    selected_record = listbox_records.curselection()
    if selected_record:
        record = listbox_records.get(selected_record)
        record_id = record[0]
        new_name = entry_name.get()
        new_email = entry_email.get()

        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()
        cursor.execute("UPDATE contacts SET name=?, email=? WHERE id=?", (new_name, new_email, record_id))
        conn.commit()
        conn.close()
        messagebox.showinfo("Success", "Record updated successfully.")
        clear_entries()
        display_records()
    else:
        messagebox.showwarning("Warning", "Please select a record to update.")

# Function to delete a record
def delete_record():
    selected_record = listbox_records.curselection()
    if selected_record:
        record = listbox_records.get(selected_record)
        record_id = record[0]

        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()
        cursor.execute("DELETE FROM contacts WHERE id=?", (record_id,))
        conn.commit()
        conn.close()
        messagebox.showinfo("Success", "Record deleted successfully.")
        clear_entries()
        display_records()
    else:
        messagebox.showwarning("Warning", "Please select a record to delete.")

# Function to clear the entry fields
def clear_entries():
    entry_name.delete(0, tk.END)
    entry_email.delete(0, tk.END)

# Create the database table
def create_table():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute("CREATE TABLE IF NOT EXISTS contacts (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, email TEXT)")
    conn.commit()
    conn.close()


# Create the main window
window = tk.Tk()
window.maxsize(width = 1280,height = 770)
window.minsize(width=1000,height=1000)
window.title("CRUD Operations")

# Create and configure the entry fields
entry_name = tk.Entry(window)
entry_name.grid(row=0, column=1, padx=10, pady=5)

entry_email = tk.Entry(window)
entry_email.grid(row=1, column=1, padx=10, pady=5)

# Create and configure the labels
label_name = tk.Label(window, text="Name:")
label_name.grid(row=0, column=0, padx=10, pady=5, sticky=tk.W)

label_email = tk.Label(window, text="Email:")
label_email.grid(row=1, column=0, padx=10, pady=5, sticky=tk.W)

# Create and configure the buttons
button_create = tk.Button(window, text="Create", command=create_record)
button_create.grid(row=2, column=0, padx=10, pady=5)

button_update = tk.Button(window, text="Update", command=update_record)
button_update.grid(row=2, column=1, padx=10, pady=5)

button_delete = tk.Button(window, text="Delete", command=delete_record)
button_delete.grid(row=2, column=2, padx=10, pady=5)

button_clear = tk.Button(window, text="Clear", command=clear_entries)
button_clear.grid(row=3, column=0, padx=10, pady=5)

# Create and configure the listbox
listbox_records = tk.Listbox(window, width=50)
listbox_records.grid(row=4, column=0, columnspan=3, padx=10, pady=5)
display_records()

# Call the create_table function to create the database table


# Start the main loop
window.mainloop()
